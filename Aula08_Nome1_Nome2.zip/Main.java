import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Seguranca seguranca = new Seguranca();

        System.out.print("Usuário: ");
        String usuario = sc.nextLine();
        System.out.print("Senha: ");
        String senha = sc.nextLine();

        if (!seguranca.autenticar(usuario, senha)) {
            System.out.println("Acesso negado!");
            return;
        }

        ClienteService service = new ClienteService();
        service.cadastrarCliente(1, "Maria");
        service.cadastrarCliente(2, "João");

        System.out.println("Clientes cadastrados:");
        service.listarClientes().forEach(c ->
            System.out.println(c.getId() + " - " + c.getNome()));

        // Exercício 2
        Cliente achado = service.buscarCliente(2);
        if (achado != null) {
            System.out.println("Encontrado: " + achado.getNome());
        } else {
            System.out.println("Cliente não encontrado");
        }
        System.out.println("Removeu 1? " + service.removerCliente(1));
        System.out.println("Removeu 9? " + service.removerCliente(9));
        service.listarClientes().forEach(c ->
            System.out.println(c.getId() + " - " + c.getNome()));

        // Exercício 3
        try {
            service.cadastrarCliente(3, "   ");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        // Exercício 4
        System.out.println("Histórico:");
        service.listarHistorico().forEach(a -> System.out.println(a));
    }
}
