public class Cliente {
    private int id;
    private String nome;

    public Cliente(int id, String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "O nome do cliente não pode ser vazio.");
        }
        this.id = id;
        this.nome = nome;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
}
