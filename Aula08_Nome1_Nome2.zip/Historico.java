import java.util.ArrayList;
import java.util.List;

public class Historico {
    private ArrayList<String> acoes = new ArrayList<>();

    public void registrar(String acao) {
        acoes.add(acao);
    }

    public List<String> listar() {
        return acoes;
    }
}
