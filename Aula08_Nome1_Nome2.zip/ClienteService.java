import java.util.List;

public class ClienteService {
    private ClienteDAO dao = new ClienteDAO();
    private Historico historico = new Historico();

    public void cadastrarCliente(int id, String nome) {
        Cliente cliente = new Cliente(id, nome);
        dao.salvar(cliente);
        historico.registrar("Cadastro: " + id + " - " + nome);
    }

    public List<Cliente> listarClientes() {
        return dao.listar();
    }

    public Cliente buscarCliente(int id) {
        historico.registrar("Busca: id " + id);
        return dao.buscarPorId(id);
    }

    public boolean removerCliente(int id) {
        boolean removeu = dao.remover(id);
        if (removeu) {
            historico.registrar("Remoção: id " + id + " (ok)");
        } else {
            historico.registrar("Remoção: id " + id + " (não encontrado)");
        }
        return removeu;
    }

    public List<String> listarHistorico() {
        return historico.listar();
    }
}
